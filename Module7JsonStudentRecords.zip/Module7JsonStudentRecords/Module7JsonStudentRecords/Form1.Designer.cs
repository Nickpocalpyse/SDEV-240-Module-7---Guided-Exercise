﻿namespace Module7JsonStudentRecords
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtStudentID = new TextBox();
            txtFirstName = new TextBox();
            txtLastName = new TextBox();
            nudGPA = new NumericUpDown();
            btnAddStudent = new Button();
            btnClearDisplay = new Button();
            btnSaveJSON = new Button();
            btnLoadJSON = new Button();
            dgvDisplayStudents = new DataGridView();
            lblStatus = new Label();
            lblStudentID = new Label();
            lblFirstName = new Label();
            lblLastName = new Label();
            lblGPA = new Label();
            lblProgram = new Label();
            txtProgram = new TextBox();
            ((System.ComponentModel.ISupportInitialize)nudGPA).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvDisplayStudents).BeginInit();
            SuspendLayout();
            // 
            // txtStudentID
            // 
            txtStudentID.Location = new Point(118, 32);
            txtStudentID.Name = "txtStudentID";
            txtStudentID.Size = new Size(77, 21);
            txtStudentID.TabIndex = 0;
            txtStudentID.Text = "Student ID";
            // 
            // txtFirstName
            // 
            txtFirstName.Location = new Point(118, 59);
            txtFirstName.Name = "txtFirstName";
            txtFirstName.Size = new Size(77, 21);
            txtFirstName.TabIndex = 1;
            txtFirstName.Text = "First Name";
            // 
            // txtLastName
            // 
            txtLastName.Location = new Point(118, 86);
            txtLastName.Name = "txtLastName";
            txtLastName.Size = new Size(77, 21);
            txtLastName.TabIndex = 2;
            txtLastName.Text = "Last Name";
            // 
            // nudGPA
            // 
            nudGPA.DecimalPlaces = 1;
            nudGPA.Increment = new decimal(new int[] { 1, 0, 0, 65536 });
            nudGPA.Location = new Point(118, 140);
            nudGPA.Maximum = new decimal(new int[] { 40, 0, 0, 65536 });
            nudGPA.Name = "nudGPA";
            nudGPA.Size = new Size(77, 21);
            nudGPA.TabIndex = 3;
            // 
            // btnAddStudent
            // 
            btnAddStudent.Location = new Point(217, 67);
            btnAddStudent.Name = "btnAddStudent";
            btnAddStudent.Size = new Size(90, 40);
            btnAddStudent.TabIndex = 4;
            btnAddStudent.Text = "Add Student";
            btnAddStudent.UseVisualStyleBackColor = true;
            btnAddStudent.Click += btnAddStudent_Click;
            // 
            // btnClearDisplay
            // 
            btnClearDisplay.Location = new Point(586, 191);
            btnClearDisplay.Name = "btnClearDisplay";
            btnClearDisplay.Size = new Size(63, 58);
            btnClearDisplay.TabIndex = 5;
            btnClearDisplay.Text = "Clear Display";
            btnClearDisplay.UseVisualStyleBackColor = true;
            btnClearDisplay.Click += btnClearDisplay_Click;
            // 
            // btnSaveJSON
            // 
            btnSaveJSON.Location = new Point(368, 191);
            btnSaveJSON.Name = "btnSaveJSON";
            btnSaveJSON.Size = new Size(63, 58);
            btnSaveJSON.TabIndex = 6;
            btnSaveJSON.Text = "Save to JSON";
            btnSaveJSON.UseVisualStyleBackColor = true;
            btnSaveJSON.Click += btnSaveJSON_Click;
            // 
            // btnLoadJSON
            // 
            btnLoadJSON.Location = new Point(481, 191);
            btnLoadJSON.Name = "btnLoadJSON";
            btnLoadJSON.Size = new Size(63, 58);
            btnLoadJSON.TabIndex = 7;
            btnLoadJSON.Text = "Load from JSON";
            btnLoadJSON.UseVisualStyleBackColor = true;
            btnLoadJSON.Click += btnLoadJSON_Click;
            // 
            // dgvDisplayStudents
            // 
            dgvDisplayStudents.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDisplayStudents.Location = new Point(326, 21);
            dgvDisplayStudents.Name = "dgvDisplayStudents";
            dgvDisplayStudents.Size = new Size(369, 150);
            dgvDisplayStudents.TabIndex = 8;
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Location = new Point(118, 172);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(122, 15);
            lblStatus.TabIndex = 9;
            lblStatus.Text = "Displays Errors Here";
            // 
            // lblStudentID
            // 
            lblStudentID.AutoSize = true;
            lblStudentID.Location = new Point(41, 38);
            lblStudentID.Name = "lblStudentID";
            lblStudentID.Size = new Size(67, 15);
            lblStudentID.TabIndex = 10;
            lblStudentID.Text = "Student ID:";
            // 
            // lblFirstName
            // 
            lblFirstName.AutoSize = true;
            lblFirstName.Location = new Point(41, 65);
            lblFirstName.Name = "lblFirstName";
            lblFirstName.Size = new Size(71, 15);
            lblFirstName.TabIndex = 11;
            lblFirstName.Text = "First Name:";
            // 
            // lblLastName
            // 
            lblLastName.AutoSize = true;
            lblLastName.Location = new Point(41, 92);
            lblLastName.Name = "lblLastName";
            lblLastName.Size = new Size(71, 15);
            lblLastName.TabIndex = 12;
            lblLastName.Text = "Last Name:";
            // 
            // lblGPA
            // 
            lblGPA.AutoSize = true;
            lblGPA.Location = new Point(41, 146);
            lblGPA.Name = "lblGPA";
            lblGPA.Size = new Size(33, 15);
            lblGPA.TabIndex = 13;
            lblGPA.Text = "GPA:";
            // 
            // lblProgram
            // 
            lblProgram.AutoSize = true;
            lblProgram.Location = new Point(41, 118);
            lblProgram.Name = "lblProgram";
            lblProgram.Size = new Size(95, 15);
            lblProgram.TabIndex = 14;
            lblProgram.Text = "Program Name:";
            lblProgram.Click += label1_Click;
            // 
            // txtProgram
            // 
            txtProgram.Location = new Point(142, 113);
            txtProgram.Name = "txtProgram";
            txtProgram.Size = new Size(98, 21);
            txtProgram.TabIndex = 15;
            txtProgram.Text = "Program Name";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(txtProgram);
            Controls.Add(lblProgram);
            Controls.Add(lblGPA);
            Controls.Add(lblLastName);
            Controls.Add(lblFirstName);
            Controls.Add(lblStudentID);
            Controls.Add(lblStatus);
            Controls.Add(dgvDisplayStudents);
            Controls.Add(btnLoadJSON);
            Controls.Add(btnSaveJSON);
            Controls.Add(btnClearDisplay);
            Controls.Add(btnAddStudent);
            Controls.Add(nudGPA);
            Controls.Add(txtLastName);
            Controls.Add(txtFirstName);
            Controls.Add(txtStudentID);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)nudGPA).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvDisplayStudents).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtStudentID;
        private TextBox txtFirstName;
        private TextBox txtLastName;
        private NumericUpDown nudGPA;
        private Button btnAddStudent;
        private Button btnClearDisplay;
        private Button btnSaveJSON;
        private Button btnLoadJSON;
        private DataGridView dgvDisplayStudents;
        private Label lblStatus;
        private Label lblStudentID;
        private Label lblFirstName;
        private Label lblLastName;
        private Label lblGPA;
        private Label lblProgram;
        private TextBox txtProgram;
    }
}
