using System.Text.Json;
using System.IO;
namespace Module7JsonStudentRecords
{
    public partial class Form1 : Form
    {
        private List<Student> students = new List<Student>();

        private void SaveJSON()
        {
            if (students.Count == 0)
            {
                lblStatus.Text = "There are no student records to save.";
                return;
            }
            string filePath = Path.Combine(Application.StartupPath, "students.json");
            string json = JsonSerializer.Serialize(students, new JsonSerializerOptions
            {
                WriteIndented = true
            });
            File.WriteAllText(filePath, json);
            lblStatus.Text = "Student records saved successfully!";
        }

        public void AddStudent()
        {
            int studentID = Int32.Parse(txtStudentID.Text);
            string firstName = txtFirstName.Text;
            string lastName = txtLastName.Text;
            string programName = txtProgram.Text;
            double gpa = Convert.ToDouble(nudGPA.Value);
            Student student = new Student
            {
                StudentId = studentID,
                FirstName = firstName,
                LastName = lastName,
                ProgramName = programName,
                GPA = gpa
            };
            students.Add(student);
            ClearDisplay();
            txtStudentID.Clear();
            txtFirstName.Clear();
            txtLastName.Clear();
            txtProgram.Clear();
            nudGPA.Value = 0;
            lblStatus.Text = "Student added successfully!";
        }

        private bool ValidateInput()
        {
            int studentID;
            if (!Int32.TryParse(txtStudentID.Text, out studentID) || studentID <= 0 || string.IsNullOrWhiteSpace(txtFirstName.Text) || string.IsNullOrWhiteSpace(txtLastName.Text) || nudGPA.Value < 0 || nudGPA.Value > 4.0m || string.IsNullOrWhiteSpace(txtProgram.Text))
            {
                lblStatus.Text = "Please fill in all fields correctly. " +
                    "Ensure the ID is a positive integer and the GPA is between 0 and 4.";

                return false;
            }
            return true;
        }

        private void ClearDisplay()
        {
            dgvDisplayStudents.DataSource = null;
            dgvDisplayStudents.DataSource = students;
        }

        private void LoadJSON()
        {
            string filePath = Path.Combine(Application.StartupPath, "students.json");
            if (!File.Exists(filePath))
            {
                lblStatus.Text = "The students.json file does not exist.";
                return;
            }
            try
            {
                string json = File.ReadAllText(filePath);
                if (string.IsNullOrWhiteSpace(json))
                {
                    lblStatus.Text = "The students.json file is empty.";
                    return;
                }
                List<Student> loadedStudents = JsonSerializer.Deserialize<List<Student>>(json);
                if (loadedStudents == null)
                {
                    lblStatus.Text = "The student data could not be loaded.";
                    return;
                }
                students = loadedStudents;
                ClearDisplay();
                lblStatus.Text = "Student records loaded successfully!";
            }
            catch (JsonException)
            {
                lblStatus.Text = "The JSON format is invalid.";
            }
            catch (IOException)
            {
                lblStatus.Text = "A file-processing error occurred.";
            }
            catch (Exception)
            {
                lblStatus.Text = "The student data could not be converted.";
            }
        }

        public Form1()
        {
            InitializeComponent();
            nudGPA.Increment = 0.1m;
            nudGPA.DecimalPlaces = 1;
            nudGPA.Minimum = 0.0m;
            nudGPA.Maximum = 4.0m;
        }


        private void btnAddStudent_Click(object sender, EventArgs e)
        {
            if (ValidateInput())
            {
                AddStudent();
            }
        }

        private void btnSaveJSON_Click(object sender, EventArgs e)
        {
            SaveJSON();
        }

        private void btnLoadJSON_Click(object sender, EventArgs e)
        {
            LoadJSON();
        }

        private void btnClearDisplay_Click(object sender, EventArgs e)
        {
            dgvDisplayStudents.DataSource = null;
            lblStatus.Text = "Student display cleared.";
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
